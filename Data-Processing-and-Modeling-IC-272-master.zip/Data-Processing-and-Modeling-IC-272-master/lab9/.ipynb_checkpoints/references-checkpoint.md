##Some useful link:

<a href="https://machinelearningmastery.com/autoregression-models-time-series-forecasting-python/">Autoregression-Models</a>