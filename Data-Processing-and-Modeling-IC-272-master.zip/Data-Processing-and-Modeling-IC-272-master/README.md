# Data Processing and Modeling
This repository contains assignments of course <strong>Data-Science (Data Processing and Modeling)</strong> course done by me in python.<br>

The libraries used:
<ol>
  <li>Numpy</li>
  <li>Pandas</li>
  <li>Matplotlib</li>
  <li>Seaborn</li>
  <li>Sci-kit learn</li>
</ol>

You can refer the <strong>Jupyter Notebooks</strong> of the same in every assignment attached within.
